<?php
include_once("php/db_connect.php");

if (isset($_POST['add'])) {
  header("location:addBonus.php");
}

if (isset($_POST['back'])) {
  header("location:afterAdminLogin.php");
}
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/employeeInfo.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="EmployeeBonus">

      <div id=heading>
        <h1>Employee Bonus</h1>
      </div>

      <div class="row">

        <div class="col-md-7 WithBonus">
          <h3 style="text-align:center; margin-Top:15px">Employee With Bonus</h3>
          <table class="infoTable">
            <tr>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Post</th>
              <th>Salary</th>
              <th>Bonus Amount</th>
              <th>Total Salary</th>

            </tr>
            <?php
            $sql ="SELECT * FROM `bonus`;";
            $result = mysqli_query($link,$sql);

              while ($data=mysqli_fetch_assoc($result)) {
                $sql ="SELECT * FROM `employeeinfo` WHERE Id=".$data['Id'].";";
                $result2 = mysqli_query($link,$sql);
                $data2=mysqli_fetch_assoc($result2);
                  echo "
                  <tr>
                  <td>{$data2['Id']}</td>
                  <td>{$data2['Name']}</td>
                  <td>{$data2['Post']}</td>
                  <td>{$data2['Salary']}</td>
                  <td>{$data['Bonus']}</td>
                  <td>{$data['Total']}</td>
                    </tr>
                  ";
            }
            ?>
          </table>
        </div>

        <div class="col-md-5 withoutBonus">
          <h3 style="text-align:center; margin-Top:15px">Employee Without Bonus</h3>
          <table class="infoTable">
            <tr>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Post</th>
              <th>Salary</th>
            </tr>

            <?php

            $sql ="SELECT * FROM `employeeinfo` WHERE bonus=0;";
            $result2 = mysqli_query($link,$sql);
            while ($data2=mysqli_fetch_assoc($result2)) {
              echo "
              <tr>
              <td>{$data2['Id']}</td>
              <td>{$data2['Name']}</td>
              <td>{$data2['Post']}</td>
              <td>{$data2['Salary']}</td>
              </tr>
              ";

            }
            ?>
          </table>
        </div>

        <div style="text-align:center" class="col-6">
          <form  method="post">
            <button id="button" type="submit" class="btn btn-default" name="add">Edit Bonus</button>
            <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
          </form>
        </div>

      </div>


</div>


</body>
</html>
