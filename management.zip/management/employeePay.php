<?php
include_once("php/db_connect.php");

$sql ="SELECT * FROM employeeinfo;";
$result = mysqli_query($link,$sql);

if (isset($_POST['status'])) {
  $Value = strip_tags($_POST['value']);
  $Id = strip_tags($_POST['id']);

  $sql ="UPDATE `employeeinfo` SET `Pay` = '".$Value."'  WHERE `employeeinfo`.`Id` = '".$Id."';";
  $Result = mysqli_query($link,$sql);

  header("location:employeePay.php");
}

if (isset($_POST['back'])) {
  header("location:afterAdminLogin.php");
}
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/employeeInfo.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="EmployeePay">

      <div id=heading>
        <h1>Employee Payment Status</h1>
      </div>

      <div class="row">

        <div class="col-md-12 ">
          <table class="infoTable">
            <tr>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Post</th>
              <th>Salary</th>
              <th>Payment Status</th>
            </tr>

            <?php

            while ($data=mysqli_fetch_assoc($result)) {
              echo "
              <tr>
              <td>{$data['Id']}</td>
              <td>{$data['Name']}</td>
              <td>{$data['Post']}</td>
              <td>{$data['Salary']}</td>
              <td>{$data['Pay']}</td>
              </tr>
              ";
            }
            ?>
          </table>
        </div>

        <div class="col-12 payDiv">
          <form  method="post">
            <input id="input" type="name" name="id" placeholder="Enter Employee ID" ><br>
            <input id="input" type="name" name="value" placeholder="Enter Status" ><br>
            <button id="button" type="submit" class="btn btn-default" name="status">Status</button>
            <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
          </form>
        </div>

      </div>

</div>

</body>
</html>
