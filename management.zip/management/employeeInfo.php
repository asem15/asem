<?php
include_once("php/db_connect.php");

$sql ="SELECT * FROM `employeeinfo`;";
$result = mysqli_query($link,$sql);


if (isset($_POST['search'])) {
  if(isset($_POST['radio'])){
    $Scolumn = $_POST['radio'];
    $Svalue = strip_tags($_POST['svalue']);
    $sql ="SELECT * FROM `employeeinfo` WHERE `employeeinfo`.`".$Scolumn."` LIKE '".$Svalue."%';";
    $result = mysqli_query($link,$sql);
  }
}


if (isset($_POST['update'])) {
  if(isset($_POST['radio1'])){
    $Column = $_POST['radio1'];
    $Value = strip_tags($_POST['value']);
    $Uid = strip_tags($_POST['uid']);

    $sql ="UPDATE `employeeinfo` SET `".$Column."` = '".$Value."'  WHERE `employeeinfo`.`Id` = '".$Uid."';";
    $Result2 = mysqli_query($link,$sql);
    header("location:employeeInfo.php");
  }
}



  if (isset($_POST['clear'])) {
    header("location:employeeInfo.php");
  }

  if (isset($_POST['add'])) {
    header("location:addEmployee.php");
  }

  if (isset($_POST['back'])) {
    header("location:afterAdminLogin.php");
  }

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/employeeInfo.css" />

  <title>Managment System</title>

</head>
<body>

<div class="employeeInfo">
  <div class="row">

  <div class="col-12" id=heading>
    <h1>Employee Information</h1>
  </div>

  <div class="col-md-7 Information">
    <table class="infoTable">
      <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>Phone Number</th>
        <th>Post</th>
        <th>Salary</th>
      </tr>
      <?php
        while ($data=mysqli_fetch_assoc($result)) {
            echo "
            <tr>
            <td>{$data['Id']}</td>
            <td>{$data['Name']}</td>
            <td>{$data['Address']}</td>
            <td>{$data['Phone']}</td>
            <td>{$data['Post']}</td>
            <td>{$data['Salary']}</td>
              </tr>
            ";
        }
      ?>
    </table>
  </div>

  <div class="col-md-5 ">
  <form method="post">
    <div class="row">

    <div class="col-5 con">
      <h3>Search</h3>
      <label class="container">Id
        <input type="radio" name="radio" value="Id">
      </label>
      <label class="container">Name
        <input type="radio" name="radio" value="Name">
      </label>
      <label class="container">Post
        <input type="radio" name="radio" value="Post">
      </label>
      <label class="container">Salary
        <input type="radio" name="radio" value="Salary">
      </label>
      <div >
      <input id="input" type="name" name="svalue" placeholder="Enter Value" ><br>
      </div>
      <button id="button" type="submit" class="btn btn-default" name="search">Search</button>
      <button id="button" type="submit" class="btn btn-default" name="clear">Clear</button>
    </div>

    <div class="col-5 con">
      <h3>Update</h3>
      <label class="container">Name
        <input type="radio" name="radio1" value="Name">
      </label>
      <label class="container">Address
        <input type="radio" name="radio1" value="Address">
      </label>
      <label class="container">Post
        <input type="radio" name="radio1" value="Post">
      </label>
      <label class="container">Salary
        <input type="radio" name="radio1" value="Salary">
      </label>
      <div>
        <input id="input" type="name" name="uid" placeholder="Enter Id" ><br>
      </div>
      <div>
        <input id="input" type="name" name="value" placeholder="Enter Value" ><br>
      </div>
      <button id="button" type="submit" class="btn btn-default" name="update">Update</button>
    </div>

    <div class="col-12">
      <button id="button" type="submit" class="btn btn-default" name="add">Add / Delete</button>
      <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
    </div>

    </div>
  </form>
  </div>


  </div>
  </div>

</body>
</html>
