<?php
include_once("php/db_connect.php");
session_start();

if (empty($_SESSION['adminid'])) {
  if (isset($_POST['admin'])) {
    $sql ="select Id from admin where name='".$_POST['name']."' and password='".md5($_POST['password'])."';";
    $result = mysqli_query($link,$sql);

    if ($data= mysqli_fetch_assoc($result)) {

      $_SESSION['adminid']=$data['Id'];
      header("location:afterAdminLogin.php");
    }
  }
}
else {
  header("location:afterAdminLogin.php");
}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="css/home.css" />
    <link rel="stylesheet" href="css/Admin.css" />

    <title>Managment System</title>
  </head>
  <body>


      <div class="AdminLogin">
        <div id=heading>
          <h1>Employee Managment System</h1>
        </div>

        <div class="loginform">
          <h3>Login</h3>
          <form class="" action="" method="POST">
            <input id="input" type="text" name="name" placeholder="User Name" required><br>
            <input id="input" type="password" name="password" placeholder="Password" required><br>
            <button id="button" type="submit" class="btn btn-default" name="admin">Admin</button>
          </form>
        </div>
      </div>
  </body>
</html>
