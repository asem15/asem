<?php
include_once("php/db_connect.php");


if(isset($_POST['add'])){
    $Name = strip_tags($_POST['name']);
    $Address = strip_tags($_POST['address']);
    $Phone = strip_tags($_POST['phone']);
    $Post = strip_tags($_POST['post']);
    $Salary = strip_tags($_POST['salary']);
    $sql ="INSERT INTO employeeInfo(Name,Address,Phone,Post,Salary) VALUES ('".$Name."', '".$Address."','".$Phone."','".$Post."','".$Salary."')";
    $result = mysqli_query($link,$sql);
    header("location:employeeInfo.php");
  }

  if (isset($_POST['delete'])) {
    $selected_name = strip_tags($_POST['name']);
    $sql = "DELETE FROM `employeeinfo` WHERE `employeeinfo`.`Name` = '".$selected_name."';";
    $result1 = mysqli_query($link,$sql);
    header("location:employeeInfo.php");
  }

  if (isset($_POST['back'])) {
    header("location:employeeInfo.php");
  }

 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/employeeInfo.css" />

  <title>Managment System</title>

</head>
<body>

<div class="employeeInfo">

  <div id=heading>
    <h1>Add or Delete Employee</h1>
  </div>

  <div class="container">

  <form action="addEmployee.php" method="post" >
  <div class="row">

    <div class="col-md-5 con2">
      <h3>Add</h3>
      <label id="l">Employee Name: </label><br>
      <input id="input1" type="name" name="name" ><br>
      <label id="l">Employee Address: </label><br>
      <input id="input1" type="name" name="address"><br>
      <label id="l">Phone Number:</label><br>
      <input id="input1" type="name" name="phone"><br>
      <label id="l">Post: </label><br>
      <input id="input1" type="name" name="post" ><br>
      <label id="l">Salary: </label><br>
      <input id="input1" type="name" name="salary" ><br>
      <div>
        <button id="button" type="submit" class="btn btn-default" name="add">Submit</button>
      </div>
    </div>

    <div class="col-md-5 con2">
      <h3>Delete</h3>
      <input id="input" type="name" name="name" placeholder="Enter name" >
      <button id="button" type="submit" class="btn btn-default" name="delete">Delete</button><br>
      <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
    </div>

  </div>
  </form>
    </div>

</div>

</body>
</html>
