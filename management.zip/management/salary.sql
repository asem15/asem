-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2019 at 06:46 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `name`, `password`) VALUES
(1, 'asem', 202);

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `attendenceId` int(11) NOT NULL,
  `Id` int(11) NOT NULL,
  `Day` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `InTime` time NOT NULL,
  `OutTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`attendenceId`, `Id`, `Day`, `Date`, `InTime`, `OutTime`) VALUES
(3, 4, 'Monday', '2019-08-14', '01:00:00', '20:00:00'),
(4, 3, 'Wednesday', '2019-08-14', '00:00:12', '00:00:21'),
(13, 3, 'Friday', '2019-08-16', '00:04:01', '06:05:02'),
(14, 3, 'Friday', '2019-08-16', '00:03:01', '06:05:04'),
(15, 3, 'Friday', '2019-08-16', '00:00:00', '04:05:06'),
(16, 3, 'Friday', '2019-08-16', '01:03:00', '00:00:00'),
(17, 3, 'Friday', '2019-08-16', '00:00:12', '00:00:06');

-- --------------------------------------------------------

--
-- Table structure for table `bonus`
--

CREATE TABLE `bonus` (
  `BonusId` int(11) NOT NULL,
  `Id` int(11) NOT NULL,
  `Bonus` int(11) NOT NULL,
  `Total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bonus`
--

INSERT INTO `bonus` (`BonusId`, `Id`, `Bonus`, `Total`) VALUES
(2, 4, 15, '46000.00'),
(4, 5, 20, '36000.00');

-- --------------------------------------------------------

--
-- Table structure for table `employeeinfo`
--

CREATE TABLE `employeeinfo` (
  `Id` int(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `Phone` int(255) NOT NULL,
  `Post` varchar(255) NOT NULL,
  `Salary` int(255) NOT NULL,
  `Bonus` int(11) NOT NULL,
  `Pay` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeeinfo`
--

INSERT INTO `employeeinfo` (`Id`, `Name`, `Address`, `Phone`, `Post`, `Salary`, `Bonus`, `Pay`) VALUES
(3, 'asem', 'Gulshan', 1343345678, 'Manager', 60000, 0, 'not paid'),
(4, 'Maliha', 'mirpur', 123456789, 'Manager', 40000, 2, 'paid'),
(5, 'Sharika', 'banani', 1234567890, 'Manager', 30000, 4, 'paid'),
(6, 'Kashfi', 'mirpur', 234567891, 'assistant manager', 30000, 0, 'paid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`attendenceId`);

--
-- Indexes for table `bonus`
--
ALTER TABLE `bonus`
  ADD PRIMARY KEY (`BonusId`);

--
-- Indexes for table `employeeinfo`
--
ALTER TABLE `employeeinfo`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `attendenceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `bonus`
--
ALTER TABLE `bonus`
  MODIFY `BonusId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `employeeinfo`
--
ALTER TABLE `employeeinfo`
  MODIFY `Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
