<?php
include_once("php/db_connect.php");

$sql ="SELECT * FROM `bonus`;";
$result = mysqli_query($link,$sql);
$result5 = mysqli_query($link,$sql);
$data5=mysqli_fetch_assoc($result5);

if (isset($_POST['add'])) {

  $Id = strip_tags($_POST['id']);

  $sql ="SELECT Salary FROM `employeeinfo` WHERE Id=".$Id.";";
  $result3 = mysqli_query($link,$sql);
  $data3=mysqli_fetch_assoc($result3);

  $B = strip_tags($_POST['bonus']);
  $Bonus= $B/100;
  $S=$data3['Salary'];
  $Total=$S+($Bonus*$S);

  $sql ="INSERT INTO `bonus` (Id,Bonus,Total)
  VALUES ('".$Id."', '".$B."', '".$Total."');";
  $result4 = mysqli_query($link,$sql);

  $sql ="SELECT * FROM `bonus` order by Id DESC;";
  $result6 = mysqli_query($link,$sql);
  $data6=mysqli_fetch_assoc($result6);

  $sql ="UPDATE `employeeinfo` SET `bonus` = '".$data6['BonusId']."'  WHERE `employeeinfo`.`Id` = '".$data6['Id']."';";
  $Result7 = mysqli_query($link,$sql);
  header("location:addBonus.php");

}

if (isset($_POST['update'])) {

  $Id = strip_tags($_POST['id']);

  $sql ="SELECT Salary FROM `employeeinfo` WHERE Id=".$Id.";";
  $result8 = mysqli_query($link,$sql);
  $data8=mysqli_fetch_assoc($result8);

  $B = strip_tags($_POST['bonus']);
  $Bonus= $B/100;
  $S=$data8['Salary'];
  $Total=$S+($Bonus*$S);

    $sql ="UPDATE `bonus` SET `Bonus` = '".$B."',`Total` = '".$Total."'  WHERE `Bonus`.`Id` = '".$Id."';";
    $Result9 = mysqli_query($link,$sql);
    header("location:addBonus.php");
  }

  if (isset($_POST['delete'])) {
    $selected_id = strip_tags($_POST['id']);
    $sql = "DELETE FROM `bonus` WHERE `bonus`.`Id` = '".$selected_id."';";
    $result10 = mysqli_query($link,$sql);

    $sql ="UPDATE `employeeinfo` SET `Bonus` = 0 WHERE `employeeinfo`.`Id` = '".$selected_id."';";
    $Result11 = mysqli_query($link,$sql);
    header("location:addBonus.php");

  }if (isset($_POST['search'])) {
    if(isset($_POST['radio'])){
      $Scolumn = $_POST['radio'];
      $Value = strip_tags($_POST['value']);
      $sql ="SELECT * FROM `bonus` WHERE `bonus`.`".$Scolumn."` LIKE '".$Value."%';";
      //$sql ="SELECT * FROM `employeeinfo` WHERE `employeeinfo`.`".$Scolumn."` LIKE '".$Value."%';";
      $result = mysqli_query($link,$sql);
    }
  }

  if (isset($_POST['clear'])) {
    header("location:addBonus.php");
  }

if (isset($_POST['back'])) {
  header("location:employeeBonus.php");
}
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/employeeInfo.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="EditBonus">

      <div id=heading>
        <h1>Edit Employee Bonus</h1>
      </div>

      <div class="row">

        <div class="col-12 Bonus">
          <table class="infoTable">
            <tr>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Post</th>
              <th>Salary</th>
              <th>Bonus Amount</th>
              <th>Total Salary</th>

            </tr>
            <?php

              while ($data=mysqli_fetch_assoc($result)) {

                $sql ="SELECT * FROM employeeinfo WHERE Id=".$data['Id'].";";
                $result2 = mysqli_query($link,$sql);
                $data2=mysqli_fetch_assoc($result2);
                  echo "
                  <tr>
                  <td>{$data2['Id']}</td>
                  <td>{$data2['Name']}</td>
                  <td>{$data2['Post']}</td>
                  <td>{$data2['Salary']}</td>
                  <td>{$data['Bonus']}</td>
                  <td>{$data['Total']}</td>
                    </tr>
                  ";
            }
            ?>
          </table>

          <form style="text-align:center" method="post">
            <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
          </form>
        </div>

        <div class="col-4 con1">
          <h3>Search</h3>
          <form method="post">
            <label class="container">Id
              <input type="radio" name="radio" value="Id">
            </label>
            <label class="container">Bonus
              <input type="radio" name="radio" value="Bonus">
            </label>
            <input id="input" type="name" name="value" placeholder="Enter Value" ><br>
            <div >
                <button id="button" type="submit" class="btn btn-default" name="search">Search</button>
                <button id="button" type="submit" class="btn btn-default" name="clear">Clear</button><br>

            </div>

          </form>
        </div>

        <div class="col-4 con1">
          <h3>Edit Bonus Info</h3>
          <form method="post">
            <input id="input" type="name" name="id" placeholder="Enter Employee ID" ><br>
            <input id="input" type="name" name="bonus" placeholder="Enter Bonus Ammount" ><br>
            <button id="button" type="submit" class="btn btn-default" name="add">Add</button>
            <button id="button" type="submit" class="btn btn-default" name="update">Update</button><br>
            <button id="button" type="submit" class="btn btn-default" name="delete">Delete</button>

          </form>
        </div>


      </div>

</div>


</body>
</html>
