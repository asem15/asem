<?php
include_once("php/db_connect.php");
session_start();

$sql ="SELECT * FROM `employeeinfo`;";
$result = mysqli_query($link,$sql);

if (isset($_POST['back'])) {
  header("location:employeeAttendence.php");
}

if (isset($_POST['back'])) {
  header("location:afterAdminLogin.php");
}

 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/employeeInfo.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="employeeAttendence">

      <div id=heading>
        <h1>Employee Attendence</h1>
      </div>

      <div class="Attendence">
        <table class="infoTable">
          <tr>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Post</th>
            <th>Salary</th>
            <th></th>
          </tr>
          <?php
            while ($data=mysqli_fetch_assoc($result)) {
                echo "
                <tr>
                <td>{$data['Id']}</td>
                <td>{$data['Name']}</td>
                <td>{$data['Address']}</td>
                <td>{$data['Phone']}</td>
                <td>{$data['Post']}</td>
                <td>{$data['Salary']}</td>
                <td>
                <a href='viewAttendence.php?id={$data['Id']}' ><button class='btn btn-default'>View</button></a>
                </td>
                  </tr>
                ";
            }

          ?>
        </table>

        <div class="b">
          <form action="" method="post">
            <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
          </form>
        </div>

      </div>

      </div>

  </body>
  </html>
