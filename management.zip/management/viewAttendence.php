<?php
include_once("php/db_connect.php");
$EID=$_GET['id'];

$sql ="SELECT * FROM attendence WHERE Id=$EID ;";
$result = mysqli_query($link,$sql);

$sql ="SELECT * FROM employeeinfo WHERE Id=$EID ;";
$result1 = mysqli_query($link,$sql);
$data1=mysqli_fetch_assoc($result1);

if (isset($_POST['add'])) {
  $In1 = strip_tags($_POST['in1']);
  $In2 = strip_tags($_POST['in2']);
  $In2 = strip_tags($_POST['in3']);
  $Out1 = strip_tags($_POST['out1']);
  $Out2 = strip_tags($_POST['out2']);
  $Out3 = strip_tags($_POST['out3']);
  $In = "$In1:$In2:$In3";
  $Out = "$Out1:$Out2:$Out3";
  $date = "20".date("y-m-d");
  $day= date("l");


  $sql="INSERT INTO attendence (Id,Day,Date,InTime,OutTime) VALUES ('".$EID."', '".$day."', '".$date."', '".$In."', '".$Out."');";
  $result3 = mysqli_query($link,$sql);
  header("location:viewAttendence.php?id=$EID");
}


if (isset($_POST['back'])) {
  header("location:employeeAttendence.php");
}
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/employeeInfo.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="employeeAttendence">
      <div id=heading>
        <h1> <?php echo $data1['Name']."'s"; ?> Attendence</h1>
      </div>

      <div class="row">

      <div class="col-6">
        <table class="infoTable">
          <tr>
            <th>Day</th>
            <th>Date</th>
            <th>In Time</th>
            <th>Out Time</th>
          </tr>
          <?php
            while ($data=mysqli_fetch_assoc($result)) {
                echo "
                <tr>
                <td>{$data['Day']}</td>
                <td>{$data['Date']}</td>
                <td>{$data['InTime']}</td>
                <td>{$data['OutTime']}</td>
                </tr>
                ";
            }

          ?>
        </table>
      </div>


      <form class="col-6" action="" method="post">
        <div class="">

          <label id="l">In Time:</label><br>
          <input id="input2" type="name" name="in1" placeholder="Hour">:
          <input id="input2" type="name" name="in2" placeholder="Minute">:
          <input id="input2" type="name" name="in3" placeholder="Second"><br>
          <label id="l">Out Time: </label><br>
          <input id="input2" type="post" name="out1" placeholder="Hour">:
          <input id="input2" type="post" name="out2" placeholder="Minute">:
          <input id="input2" type="post" name="out3" placeholder="Second"><br>
          <button id="button" type="submit" class="btn btn-default" name="add">Add</button>
          <button id="button" type="submit" class="btn btn-default" name="back">Back</button>
        </div>
      </form>

    </div>
  </div>


  </body>
  </html>
