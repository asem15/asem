<?php
include_once("php/db_connect.php");
session_start();

if (isset($_SESSION['adminid'])) {


  if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("location:adminlogin.php");
  }
  elseif (isset($_POST['info'])) {
    header("location:employeeInfo.php");
  }
  elseif (isset($_POST['attendence'])) {
    header("location:employeeAttendence.php");
}
  elseif (isset($_POST['bonus'])) {
    header("location:employeeBonus.php");
}

elseif (isset($_POST['pay'])) {
  header("location:employeePay.php");
}


}
else {
  header("location:adminlogin.php");
}


 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/Admin.css" />

    <title>Managment System</title>

  </head>
  <body>

    <div class="AfterAdminLogin">
      <div id=heading>
        <h1>Admin</h1>
      </div>

      <form action="" method="post">
        <div>
          <button id="button" type="submit" class="btn btn-default" name="info">Employee Info</button>
        </div>

        <div>
          <button id="button" type="submit" class="btn btn-default" name="attendence">Employee Attendence</button>
        </div>

        <div>
          <button id="button" type="submit" class="btn btn-default" name="bonus">Employe Bonus</button>
        </div>

        <div>
          <button id="button" type="submit" class="btn btn-default" name="pay">Employee Payment Status</button>
        </div>

        <div>
          <button id="button" type="submit" class="btn btn-default" name="logout">Log Out</button>
        </div>

      </form>

    </div>

  </body>
</html>
